import pandas as pd
import sqlite3

conn = sqlite3.connect("ecommerce_dw.db")
cursor = conn.cursor()

cursor.execute("""CREATE TABLE IF NOT EXISTS customers (
    customer_id INTEGER PRIMARY KEY,
    name TEXT,
    city TEXT
)""")

cursor.execute("""CREATE TABLE IF NOT EXISTS products (
    product_id INTEGER PRIMARY KEY,
    product_name TEXT,
    price INTEGER
)""")

cursor.execute("""CREATE TABLE IF NOT EXISTS orders (
    order_id INTEGER PRIMARY KEY,
    customer_id INTEGER,
    product_id INTEGER,
    quantity INTEGER,
    date TEXT
)""")

print("Tables Created Successfully!")

try:
    customers = pd.read_csv("customers.csv")
    products = pd.read_csv("products.csv")
    orders = pd.read_csv("orders.csv")

    customers.to_sql("customers", conn, if_exists="replace", index=False)
    products.to_sql("products", conn, if_exists="replace", index=False)
    orders.to_sql("orders", conn, if_exists="replace", index=False)

    print("ETL Process Completed Successfully!")

except Exception as e:
    print("Error in ETL Process:", e)

print("\n📊 SALES ANALYSIS REPORT")

query1 = """
SELECT SUM(o.quantity * p.price) AS total_sales
FROM orders o
JOIN products p ON o.product_id = p.product_id
"""
print("\nTotal Sales:")
print(pd.read_sql(query1, conn))

query2 = """
SELECT p.product_name, SUM(o.quantity) AS total_sold
FROM orders o
JOIN products p ON o.product_id = p.product_id
GROUP BY p.product_name
ORDER BY total_sold DESC
"""
print("\nTop Selling Products:")
print(pd.read_sql(query2, conn))

query3 = """
SELECT c.name, SUM(o.quantity * p.price) AS total_spent
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN products p ON o.product_id = p.product_id
GROUP BY c.name
ORDER BY total_spent DESC
"""
print("\nCustomer Spending:")
print(pd.read_sql(query3, conn))

conn.close()
print("\nProcess Completed Successfully!")
